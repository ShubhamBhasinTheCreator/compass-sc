import { Link, useLocation } from "wouter";
import { useAuth } from "@workspace/replit-auth-web";
import { useGetRoles } from "@workspace/api-client-react";
import { CompassMark } from "@/components/compass-mark";
import { markDemoActive } from "@/lib/case-store";
import { ROLE_HOME, ROLE_LABELS, useDemoRole, type DemoRole } from "@/lib/demo-role";

const NAV: Record<DemoRole, { href: string; label: string }[]> = {
  student: [
    { href: "/", label: "Home" },
    { href: "/my-cases", label: "My Cases" },
    { href: "/privacy", label: "Privacy" },
  ],
  office: [{ href: "/office", label: "Inbox" }],
  usg: [
    { href: "/usg", label: "Pulse" },
    { href: "/usg/themes", label: "Themes" },
    { href: "/usg/brief", label: "Weekly brief" },
  ],
};

export function DemoSwitcher({ demoMode }: { demoMode: boolean }) {
  const { role, setRole } = useDemoRole();
  const [, navigate] = useLocation();
  if (!demoMode) return null;
  return (
    <div className="border-b border-[#ebe6dc] bg-white/70 backdrop-blur" data-testid="demo-switcher">
      <div className="mx-auto flex max-w-5xl flex-wrap items-center gap-x-3 gap-y-2 px-4 py-2 sm:px-6">
        <span className="rounded-full border border-[#990000]/30 bg-white px-2.5 py-0.5 text-[11px] font-bold uppercase tracking-[0.12em] text-[#990000]">
          Demo
        </span>
        <span id="demo-label" className="text-sm font-medium text-[#4a3f38]">View as</span>
        <div role="radiogroup" aria-labelledby="demo-label" className="flex rounded-full bg-[#f4f1ea] p-1">
          {(Object.keys(ROLE_LABELS) as DemoRole[]).map((r) => (
            <button
              key={r}
              type="button"
              role="radio"
              aria-checked={role === r}
              data-testid={`button-demo-role-${r}`}
              onClick={() => {
                markDemoActive();
                setRole(r);
                navigate(ROLE_HOME[r]);
              }}
              className={`min-h-9 rounded-full px-3.5 text-sm font-semibold transition-colors ${
                role === r ? "bg-white text-[#990000] shadow-[0_1px_3px_rgba(31,26,23,.12)]" : "text-[#6b625b] hover:text-[#1f1a17]"
              }`}
            >
              {ROLE_LABELS[r]}
            </button>
          ))}
        </div>
        <span className="text-xs text-[#6d6058]">Judges can preview all three areas without an account.</span>
      </div>
    </div>
  );
}

export function SiteHeader({ demoMode }: { demoMode: boolean }) {
  const { role } = useDemoRole();
  const [location] = useLocation();
  const { data: roles } = useGetRoles();
  const { login, logout } = useAuth();
  const links = roles?.admin ? [...NAV[role], { href: "/admin", label: "Admin" }] : NAV[role];
  return (
    <header className="sticky top-0 z-40 bg-[#fdfbf7]/90 backdrop-blur supports-[backdrop-filter]:bg-[#fdfbf7]/75">
      <DemoSwitcher demoMode={demoMode} />
      <div className="mx-auto flex max-w-5xl items-center justify-between gap-3 px-4 py-3 sm:px-6">
        <Link href="/" className="flex items-center gap-2.5 rounded-xl" data-testid="link-home-logo">
          <CompassMark className="h-9 w-9 shrink-0" />
          <span className="leading-tight">
            <span className="block text-[17px] font-extrabold tracking-tight text-[#990000]">Compass SC</span>
            <span className="block text-[11px] font-medium uppercase tracking-[0.14em] text-[#7a6d63]">By Trojans, for Trojans</span>
          </span>
        </Link>
        <nav aria-label="Main" className="flex flex-wrap items-center justify-end gap-1">
          {links.map((n) => {
            const active = location === n.href;
            return (
              <Link
                key={n.href}
                href={n.href}
                aria-current={active ? "page" : undefined}
                data-testid={`link-nav-${n.label.toLowerCase().replace(/\s+/g, "-")}`}
                className={`relative min-h-10 rounded-xl px-2.5 py-2 text-sm font-semibold transition-colors sm:px-3 ${
                  active ? "text-[#990000]" : "text-[#4a3f38] hover:bg-[#f3ece2]"
                }`}
              >
                {n.label}
                {active && <span className="absolute inset-x-3 -bottom-0.5 h-[3px] rounded-full bg-[#FFCC00]" />}
              </Link>
            );
          })}
          <button
            type="button"
            onClick={() => (roles?.signedIn ? logout() : login())}
            data-testid={roles?.signedIn ? "button-logout" : "button-login"}
            className="min-h-10 rounded-xl px-2.5 text-sm font-semibold text-[#7a6d63] hover:bg-[#f3ece2] sm:px-3"
          >
            {roles?.signedIn ? "Log out" : "Log in"}
          </button>
        </nav>
      </div>
      <div className="h-px bg-gradient-to-r from-transparent via-[#e6dccf] to-transparent" />
    </header>
  );
}
