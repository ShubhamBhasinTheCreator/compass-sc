import { useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";
import { ArrowRight, RotateCw } from "lucide-react";
import { useRouteProblem } from "@workspace/api-client-react";
import { setCurrentCase } from "@/lib/case-store";
import { PipelineStepper } from "@/components/result/pipeline-stepper";

export const EXAMPLE_CHIPS = [
  "I missed the deadline to drop a class",
  "My financial aid is late and rent is due",
  "I can't afford food this week",
  "My landlord won't fix my heater",
  "When is my final exam?",
  "I lost my USC ID",
];

const LIMIT = 1500;

const TYPED_EXAMPLES = [
  "My USC card got stolen…",
  "My landlord won't return my deposit…",
  "I can't afford groceries this week…",
  "When is my final for a MWF 10am class?…",
  "I feel really overwhelmed…",
];

/** Cycles example problems in the placeholder, typed out letter by letter. */
function useTypewriter(active: boolean) {
  const [out, setOut] = useState("");
  useEffect(() => {
    if (!active) { setOut(""); return; }
    if (window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) { setOut(TYPED_EXAMPLES[0]); return; }
    let word = 0, pos = 0, deleting = false;
    let timer = 0;
    const tick = () => {
      const full = TYPED_EXAMPLES[word];
      if (!deleting) {
        pos += 1; setOut(full.slice(0, pos));
        if (pos >= full.length) { deleting = true; timer = window.setTimeout(tick, 1300); return; }
        timer = window.setTimeout(tick, 34);
      } else {
        pos -= 2; setOut(full.slice(0, Math.max(pos, 0)));
        if (pos <= 0) { deleting = false; pos = 0; word = (word + 1) % TYPED_EXAMPLES.length; timer = window.setTimeout(tick, 250); return; }
        timer = window.setTimeout(tick, 14);
      }
    };
    timer = window.setTimeout(tick, 500);
    return () => window.clearTimeout(timer);
  }, [active]);
  return out;
}

export function ProblemBox({ initialText = "", initialChip = false }: { initialText?: string; initialChip?: boolean }) {
  const [text, setText] = useState(initialText);
  // Once a chip is used, the submission stays a test entry even if edited.
  const [usedChip, setUsedChip] = useState(initialChip);
  const ref = useRef<HTMLTextAreaElement>(null);
  const [, navigate] = useLocation();
  const route = useRouteProblem();
  const empty = text.trim().length === 0;
  const over = text.length > LIMIT;
  const busy = route.isPending;
  const [focused, setFocused] = useState(false);
  const typed = useTypewriter(!focused && empty);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const el = e.target as HTMLElement | null;
      const typing = !!el && (el.tagName === "INPUT" || el.tagName === "TEXTAREA" || el.isContentEditable);
      if (e.key === "/" && !typing) { e.preventDefault(); ref.current?.focus(); }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const submit = () => {
    if (empty || over || busy) return;
    // Only example chips are test entries. A problem a student types is always real.
    const isTest = usedChip;
    route.mutate(
      { data: { text: text.trim(), isTest, chip: usedChip } },
      {
        onSuccess: (result) => {
          setCurrentCase({ result, writeup: result.writeup, isTest: result.isTest, createdAt: new Date().toISOString() });
          navigate("/result");
        },
      },
    );
  };

  return (
    <div className="glow-card rounded-[28px] bg-white p-3 shadow-[0_1px_2px_rgba(31,26,23,.04),0_20px_50px_-30px_rgba(31,26,23,.25)] ring-1 ring-[#ebe6dc] sm:p-4">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          submit();
        }}
      >
        <label htmlFor="problem" className="block px-2 pt-1 text-lg font-bold text-[#241d19]">
          What's going on?
        </label>
        <p id="problem-hint" className="px-2 pb-2 text-sm text-[#6d6058]">
          One problem, in your own words. No name or USC ID needed.
        </p>
        <textarea
          id="problem"
          ref={ref}
          value={text}
          disabled={busy}
          onChange={(e) => {
            setText(e.target.value);
            route.reset();
          }}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          onKeyDown={(e) => { if ((e.metaKey || e.ctrlKey) && e.key === "Enter") { e.preventDefault(); submit(); } }}
          rows={5}
          aria-describedby={`problem-hint${over ? " problem-count" : ""}`}
          aria-invalid={over}
          placeholder={typed || "Tell us what's going on…"}
          data-testid="input-problem"
          className="block w-full resize-y rounded-2xl border-0 bg-[#faf9f5] px-4 py-3.5 text-base leading-relaxed text-[#241d19] placeholder:text-[#9a8d82] ring-1 ring-inset ring-[#eadfd1] transition-shadow focus:outline-none focus:ring-2 focus:ring-[#990000] focus:shadow-[0_0_0_6px_rgba(255,204,0,.28)] disabled:opacity-70"
        />
        <div className="flex flex-col-reverse items-stretch gap-3 px-1 pt-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="min-h-5 text-sm" aria-live="polite">
            {over && (
              <span id="problem-count" className="font-semibold text-[#990000]" data-testid="text-char-count">
                {text.length.toLocaleString()} / 1,500 characters. Please shorten it by {(text.length - LIMIT).toLocaleString()}.
              </span>
            )}
            {usedChip && !over && (
              <span className="inline-flex items-center gap-1.5 text-[#6d6058]" data-testid="status-test-entry">
                <span className="rounded-full bg-[#efe6da] px-2 py-0.5 text-[11px] font-bold uppercase tracking-wider text-[#4a3f38]">test</span>
                Example entries are not counted.
              </span>
            )}
          </div>
          <button
            type="submit"
            disabled={empty || over || busy}
            data-testid="button-get-help"
            className="btn-gold inline-flex min-h-12 items-center justify-center gap-2 rounded-2xl px-7 text-base font-bold"
          >
            {busy ? "Working on it" : "Get help"}
            <ArrowRight className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>
      </form>

      {busy && (
        <div className="mx-1 mt-4" aria-live="polite">
          <PipelineStepper pending />
        </div>
      )}

      {route.isError && (
        <div role="alert" className="mx-1 mt-4 flex flex-wrap items-center gap-3 rounded-2xl bg-[#fff1ee] p-4 text-sm text-[#5a1a12] ring-1 ring-[#f0c9c0]" data-testid="status-route-error">
          <p className="flex-1">We couldn't build your case just now. Your words are still in the box.</p>
          <button
            type="button"
            onClick={submit}
            data-testid="button-retry-route"
            className="inline-flex min-h-10 items-center gap-1.5 rounded-xl bg-white px-3 font-semibold text-[#990000] ring-1 ring-[#e3d6c4] hover:bg-[#fff6d6]"
          >
            <RotateCw className="h-4 w-4" aria-hidden="true" /> Retry
          </button>
        </div>
      )}

      <div className="mt-4 px-1 pb-1">
        <p className="mb-2 text-xs font-semibold uppercase tracking-[0.14em] text-[#7a6d63]">Try an example</p>
        <ul className="flex flex-wrap gap-2">
          {EXAMPLE_CHIPS.map((c, i) => (
            <li key={c} className="rise" style={{ animationDelay: `${260 + i * 45}ms` }}>
              <button
                type="button"
                disabled={busy}
                data-testid={`button-chip-${i}`}
                onClick={() => {
                  setText(c);
                  setUsedChip(true);
                  route.reset();
                  ref.current?.focus();
                }}
                className="min-h-10 rounded-full bg-white px-3.5 py-2 text-left text-sm text-[#4a423c] ring-1 ring-[#e6e0d6] transition-[background-color,transform,box-shadow] hover:-translate-y-px hover:bg-[#fffaf0] hover:ring-[#e8c766] active:translate-y-0 disabled:opacity-60"
              >
                {c}
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
