import { Link } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { ArrowUpRight, RotateCw, ShieldCheck } from "lucide-react";
import { getGetCompassCatalogQueryKey, useGetCompassCatalog } from "@workspace/api-client-react";

function fmtDate(s: string) {
  // String-based so the time zone can never shift the day.
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s || "");
  if (!m) return s;
  return `${["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][Number(m[2]) - 1]} ${Number(m[3])}, ${m[1]}`;
}

export function CatalogLine() {
  const { data, isLoading, isError } = useGetCompassCatalog();
  const qc = useQueryClient();
  if (isLoading) return <div className="h-5 w-64 animate-pulse rounded-full bg-[#efe6da]" aria-label="Loading resource count" />;
  if (isError || !data)
    return (
      <div className="flex flex-wrap items-center gap-2 text-sm text-[#4a3f38]" role="alert">
        <span>We couldn't reach Compass SC just now.</span>
        <button
          type="button"
          onClick={() => qc.invalidateQueries({ queryKey: getGetCompassCatalogQueryKey() })}
          data-testid="button-retry-catalog"
          className="inline-flex min-h-10 items-center gap-1.5 rounded-xl bg-white px-3 font-semibold text-[#990000] ring-1 ring-[#e3d6c4] hover:bg-[#fff6d6]"
        >
          <RotateCw className="h-4 w-4" aria-hidden="true" /> Retry
        </button>
      </div>
    );
  return (
    <p className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-[#4a3f38]" data-testid="text-catalog-line">
      <span className="inline-flex items-center gap-1.5">
        <ShieldCheck className="h-4 w-4 text-[#990000]" aria-hidden="true" />
        <span>
          <strong className="font-mono font-medium text-[#241d19]">{data.count}</strong> checked USC resources, last checked{" "}
          {fmtDate(data.lastChecked)}
        </span>
      </span>
      <Link href="/who-sees-what" className="font-semibold text-[#990000] underline underline-offset-4" data-testid="link-who-sees-what">
        Who sees what
      </Link>
    </p>
  );
}

export function HeadsUpStrip() {
  const { data, isLoading } = useGetCompassCatalog();
  if (isLoading)
    return (
      <div className="grid gap-3 sm:grid-cols-3">
        {[0, 1, 2].map((i) => (
          <div key={i} className="h-32 animate-pulse rounded-3xl bg-[#f3ece2]" />
        ))}
      </div>
    );
  const items = (data?.headsUp ?? []).slice(0, 3);
  if (items.length === 0) return null;
  return (
    <section aria-labelledby="headsup-title" className="rise" style={{ animationDelay: "240ms" }}>
      <div className="mb-4 flex items-baseline gap-3">
        <h2 id="headsup-title" className="text-lg font-semibold tracking-tight">Heads-up this week</h2>
        <span className="h-px flex-1 bg-[#e6dccf]" />
      </div>
      <ul className="grid gap-3 sm:grid-cols-3">
        {items.map((h, i) => (
          <li key={h.url + i}>
            <a
              href={h.url}
              target="_blank"
              rel="noopener noreferrer"
              data-testid={`card-headsup-${i}`}
              className="glow-card group flex h-full flex-col rounded-[20px] bg-white p-5 ring-1 ring-[#ebe6dc]"
            >
              <span className="flex items-center gap-2 font-semibold text-[#1f1a17]"><span aria-hidden="true" className="h-1.5 w-1.5 shrink-0 rounded-full bg-[#FFCC00] ring-2 ring-[#FFCC00]/30" />{h.title}</span>
              <span className="mt-1.5 flex-1 text-sm leading-relaxed text-[#5a4e46]">{h.detail}</span>
              <span className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-[#990000]">
                Official page <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" aria-hidden="true" />
                <span className="sr-only">(opens in a new tab)</span>
              </span>
            </a>
          </li>
        ))}
      </ul>
    </section>
  );
}
