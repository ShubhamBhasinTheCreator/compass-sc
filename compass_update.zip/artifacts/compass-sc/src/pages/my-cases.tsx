import { useState } from "react";
import { Link, useLocation } from "wouter";
import { ArrowRight, FolderOpen, Trash2 } from "lucide-react";
import { TestTag } from "@/components/result/case-writeup";
import { getSavedCases, markRevealed, removeSavedCase, setCurrentCase } from "@/lib/case-store";
import { useListCases, type PilotCase } from "@workspace/api-client-react";
import { allSubmittedTokens, getSubmittedCase } from "@/lib/pilot-case-store";

export default function MyCases() {
  const [cases, setCases] = useState(() => getSavedCases());
  const [, navigate] = useLocation();
  const tokens = allSubmittedTokens();
  const tracked = useListCases(undefined, {
    query: { enabled: tokens.length > 0, refetchInterval: 15000, queryKey: ["/api/compass/cases", "mine", tokens] },
    request: { headers: { "x-case-tokens": tokens } },
  });
  const byId = new Map(((tracked.data ?? []) as PilotCase[]).map((c) => [c.id, c]));

  return (
    <div className="mx-auto max-w-3xl px-4 pt-10 sm:px-6 sm:pt-14">
      <h1 className="rise text-3xl font-extrabold tracking-tight sm:text-4xl">My Cases</h1>
      <p className="rise mt-2 text-[#5a4e46]" style={{ animationDelay: "60ms" }}>
        Cases you save are kept in this browser only.
      </p>
      {cases.length === 0 ? (
        <div className="rise mt-8 rounded-[20px] border border-[#ebe6dc] bg-white px-6 py-14 text-center" style={{ animationDelay: "120ms" }} data-testid="status-empty-cases">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-[#fff1bf]">
            <FolderOpen className="h-7 w-7 text-[#990000]" aria-hidden="true" />
          </div>
          <h2 className="mt-4 text-xl font-bold">No cases yet</h2>
          <p className="mx-auto mt-2 max-w-sm text-sm text-[#5a4e46]">
            Tell Compass what’s going on. Cases you save or send to an office show up here, with their status.
          </p>
          <Link href="/" data-testid="link-start-case" className="btn-gold mt-6 inline-flex min-h-11 items-center gap-2 rounded-xl px-5 text-sm font-bold">
            Describe a problem <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </Link>
        </div>
      ) : (
        <ul className="mt-8 space-y-3">
          {cases.map((c, i) => (
            <li key={c.result.id} className="rise rounded-[24px] bg-white p-5 ring-1 ring-[#eadfd1]" style={{ animationDelay: `${i * 50}ms` }} data-testid={`card-case-${c.result.id}`}>
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-bold uppercase tracking-[0.14em] text-[#990000]">{c.result.category}</span>
                {c.isTest && <TestTag />}
                <span className="ml-auto text-xs text-[#7a6d63]">Saved {new Date(c.savedAt ?? c.createdAt).toLocaleDateString("en-US", { month: "short", day: "numeric" })}</span>
              </div>
              <p className="mt-1 font-bold">{c.result.primary.title}</p>
              <p className="mt-1 line-clamp-2 text-sm text-[#5a4e46]">{c.writeup.summary}</p>
              {(() => {
                const ref = getSubmittedCase(c.result.id);
                const live = ref ? byId.get(ref.caseId) : undefined;
                if (!ref) return <p className="mt-2 text-xs text-[#6d6058]">Not sent to an office yet. Open it and press "Submit to office".</p>;
                const steps = ["Received", "In progress", "Resolved"];
                const at = Math.max(0, steps.indexOf(live?.status ?? "Received"));
                return (
                  <div className="mt-3 rounded-2xl bg-[#faf6f0] p-3" data-testid={`status-tracking-${c.result.id}`}>
                    <p className="text-xs font-bold uppercase tracking-[0.12em] text-[#7a6d63]">Case {ref.publicCode}</p>
                    <ol className="mt-2 flex items-center gap-2">
                      {steps.map((s, k) => (
                        <li key={s} className="flex flex-1 items-center gap-2">
                          <span className={`h-2.5 flex-1 rounded-full transition-colors duration-300 ${k <= at ? "bg-[#990000]" : "bg-[#e9dfd2]"}`} />
                          <span className={`text-xs font-semibold ${k <= at ? "text-[#990000]" : "text-[#9a8d82]"}`}>{s}</span>
                        </li>
                      ))}
                    </ol>
                    {live?.replies.map((r, k) => (
                      <p key={k} className="pop-in mt-2 rounded-xl border-l-4 border-[#FFCC00] bg-white p-2.5 text-sm"><span className="text-xs text-[#7a6d63]">Reply from the office</span><br />{r.text}</p>
                    ))}
                  </div>
                );
              })()}
              <div className="mt-3 flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => { setCurrentCase(c); markRevealed(c.result.id); navigate("/result"); }}
                  data-testid={`button-open-case-${c.result.id}`}
                  className="inline-flex min-h-10 items-center gap-1.5 rounded-xl bg-[#990000] px-4 text-sm font-bold text-[#fff7ea]"
                >
                  Open <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </button>
                <button
                  type="button"
                  onClick={() => { if (window.confirm("Remove this case from this browser?")) { removeSavedCase(c.result.id); setCases(getSavedCases()); } }}
                  data-testid={`button-remove-case-${c.result.id}`}
                  className="inline-flex min-h-10 items-center gap-1.5 rounded-xl px-3 text-sm font-semibold text-[#5a4e46] ring-1 ring-[#e3d6c4] hover:bg-[#faf6f0]"
                >
                  <Trash2 className="h-4 w-4" aria-hidden="true" /> Remove
                </button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
