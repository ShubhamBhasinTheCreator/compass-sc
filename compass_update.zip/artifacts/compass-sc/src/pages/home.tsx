import { CompassMark } from "@/components/compass-mark";
import { ProblemBox } from "@/components/problem-box";
import { CatalogLine, HeadsUpStrip } from "@/components/catalog-status";

const HOW = [
  { n: "01", t: "You tell us once", d: "One problem, plain words. No account, no NetID." },
  { n: "02", t: "We find the office", d: "Matched only against checked, official USC pages." },
  { n: "03", t: "You get a finished case", d: "Steps, deadline, sources and a request ready to send." },
];

export default function Home() {
  return (
    <div className="mx-auto max-w-5xl px-4 sm:px-6">
      <section className="relative pt-12 sm:pt-20">
        <div aria-hidden="true" className="pointer-events-none absolute -right-24 -top-10 hidden opacity-[0.045] sm:block">
          <CompassMark className="h-96 w-96" spin />
        </div>
        <p className="rise text-xs font-semibold uppercase tracking-[0.2em] text-[#990000]">Free · Student-built · No sign-in</p>
        <h1 className="rise mt-3 max-w-3xl text-[2.6rem] font-extrabold leading-[1.02] tracking-[-0.03em] text-[#241d19] sm:text-6xl" style={{ animationDelay: "60ms" }}>
          One box for <span className="relative whitespace-nowrap text-[#990000]">all of USC.<span aria-hidden="true" className="absolute -bottom-1 left-0 h-2 w-full rounded-full bg-[#FFCC00]/70 -z-10" /></span>
        </h1>
        <p className="rise mt-5 max-w-xl text-lg text-[#6b625b] sm:text-xl" style={{ animationDelay: "120ms" }}>
          Tell us what's wrong. We'll handle the next step.
        </p>
        <div className="rise relative mt-10" style={{ animationDelay: "180ms" }}>
          <ProblemBox />
        </div>
        <div className="mt-5 px-1">
          <CatalogLine />
        </div>
      </section>

      <div className="mt-14">
        <HeadsUpStrip />
      </div>

      <section aria-labelledby="how-title" className="mt-20 border-t border-[#ebe6dc] pt-10">
        <h2 id="how-title" className="text-xs font-semibold uppercase tracking-[0.2em] text-[#990000]">Not a chat. A case.</h2>
        <ol className="mt-6 grid gap-8 sm:grid-cols-3">
          {HOW.map((h, i) => (
            <li key={h.n} className="rise" style={{ animationDelay: `${300 + i * 70}ms` }}>
              <span className="font-mono text-sm text-[#990000]">{h.n}</span>
              <p className="mt-2 text-lg font-semibold tracking-tight text-[#1f1a17]">{h.t}</p>
              <p className="mt-1.5 text-[0.95rem] leading-relaxed text-[#6b625b]">{h.d}</p>
            </li>
          ))}
        </ol>
      </section>
    </div>
  );
}
